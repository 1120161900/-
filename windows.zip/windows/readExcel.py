import xlrd
from PyQt5.QtWidgets import *

def read_excel(tableWidget, sheet,nowpath):
    workbook = xlrd.open_workbook(nowpath+'result1.xls')
    sheet1 = workbook.sheet_by_index(sheet)
    cols = sheet1.col_values(1)
#    print(cols)
    for i in range(len(cols)):
        rowslist = sheet1.row_values(i) # 获取excel每行内容
        for j in range(len(rowslist)):
            row = tableWidget.rowCount()
            tableWidget.insertRow(row)
            try:
                newItem = QTableWidgetItem(str(rowslist[j]))
                tableWidget.setItem(i - 1, j, newItem)
                print(i-1,j)
            except:
                continue
