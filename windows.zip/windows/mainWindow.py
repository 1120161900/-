#123小组木马检测系统
# -!- coding: utf-8 -!-
import sys, ctypes, xlrd
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import readExcel
from pcap_an import *
import os
import shutil

class Ui_widget(QWidget):
    def __init__(self):
        self.nowpath=" "
        super().__init__()
        self.setupUi()
        self.beautifyUi()

    def setupUi(self):
        self.setObjectName("widget")
        self.resize(574, 451)
        self.pushButton = QtWidgets.QPushButton(self)
        self.pushButton.setGeometry(QtCore.QRect(240, 130, 111, 101))
        self.pushButton.setText("")
        self.pushButton.setIconSize(QtCore.QSize(50, 50))
        self.pushButton.setObjectName("pushButton")
        self.label = QtWidgets.QLabel(self)
        self.label.setGeometry(QtCore.QRect(50, 0, 201, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(14)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.pushButton_2 = QtWidgets.QPushButton(self)
        self.pushButton_2.setGeometry(QtCore.QRect(50, 130, 111, 101))
        self.pushButton_2.setLayoutDirection(QtCore.Qt.RightToLeft)
        self.pushButton_2.setText("")
        self.pushButton_2.setIconSize(QtCore.QSize(50, 50))
        self.pushButton_2.setObjectName("pushButton_2")
        self.minimize = QtWidgets.QPushButton(self)
        self.minimize.setGeometry(QtCore.QRect(490, 4, 31, 31))
        self.minimize.setText("")
        self.minimize.setObjectName("minimize")
        self.close = QtWidgets.QPushButton(self)
        self.close.setGeometry(QtCore.QRect(530, 4, 31, 31))
        self.close.setText("")
        self.close.setObjectName("close")
        self.label_2 = QtWidgets.QLabel(self)
        self.label_2.setGeometry(QtCore.QRect(50, 275, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self)
        self.label_3.setGeometry(QtCore.QRect(10, 1, 35, 35))
        self.label_3.setLineWidth(-1)
        self.label_3.setText("")
        self.label_3.setPixmap(QtGui.QPixmap("C:/Users/Agazelle for Lessons/.designer/backup/P1.png"))
        self.label_3.setScaledContents(True)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self)
        self.label_4.setGeometry(QtCore.QRect(-10, -10, 601, 51))
        self.label_4.setText("")
        self.label_4.setObjectName("label_4")
        self.textEdit = QtWidgets.QTextEdit(self)
        self.textEdit.setGeometry(QtCore.QRect(50, 310, 481, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.textEdit.setFont(font)
        self.textEdit.setObjectName("textEdit")
        self.pushButton_3 = QtWidgets.QPushButton(self)
        self.pushButton_3.setGeometry(QtCore.QRect(420, 130, 111, 101))
        self.pushButton_3.setText("")
        self.pushButton_3.setIconSize(QtCore.QSize(50, 50))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.childfrome)

        self.label.raise_()
        self.label_3.raise_()
        self.close.raise_()
        self.minimize.raise_()

        self.retranslateUi(self)
        self.pushButton.clicked.connect(lambda :self.beginTest())
        self.pushButton_2.clicked.connect(lambda :self.showDialog())
        self.close.clicked.connect(QCoreApplication.instance().quit)
        self.minimize.clicked.connect(lambda: self.showMinimized())
        QtCore.QMetaObject.connectSlotsByName(self)

    @pyqtSlot()
    def childfrome(self):
        self.child = main_widget(self.nowpath)

    def retranslateUi(self, widget):
        _translate = QtCore.QCoreApplication.translate
        widget.setWindowTitle(_translate("widget", "Form"))
        self.label.setText(_translate("widget", "123小组木马检测系统"))
        self.label_2.setText(_translate("widget", "文件路径："))

    def beautifyUi(self):
        self.setWindowIcon(QIcon('P1.png'))  #设置窗口图标
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("myappid")  #设置任务栏图标
        self.label_3.setPixmap(QPixmap('P1.png'))
        self.pushButton_2.setIcon(QIcon('P2.png'))
        self.pushButton.setIcon(QIcon('P3.png'))
        self.pushButton_3.setIcon(QIcon('P4.png'))
        self.minimize.setIcon(QIcon('P5.png'))
        self.close.setIcon(QIcon('P6.png'))
        self.close.setFixedSize(30, 30)  # 设置关闭按钮的大小
        self.minimize.setFixedSize(30, 30)  # 设置最小化按钮大小
        self.pushButton_2.setFixedSize(100, 100)
        self.pushButton.setFixedSize(100, 100)
        self.pushButton_3.setFixedSize(100, 100)
        self.close.setStyleSheet(
            '''QPushButton{background:#F76677;border-radius:15px;}QPushButton:hover{background:red;}''')
        self.minimize.setStyleSheet(
            '''QPushButton{background:#6DDF6D;border-radius:15px;}QPushButton:hover{background:green;}''')
        self.pushButton_2.setStyleSheet(
            '''QPushButton{background:#D2F7A5;border-radius:50px;}QPushButton:hover{background:#BFF77C;}''')
        self.pushButton.setStyleSheet(
            '''QPushButton{background:#FF3EFF;border-radius:50px;}QPushButton:hover{background:#FF2EFF;}''')
        self.pushButton_3.setStyleSheet(
            '''QPushButton{background:blue;border-radius:50px;}QPushButton:hover{background:purple;}''')
        self.label.setStyleSheet(
            '''QLabel{color:Black;border-radius:45px;
                            font-size:14pt; font-weight:400;font-family: Roman times;} ''')
        self.label_4.setStyleSheet(
            '''QLabel{color:darkGray;background:lightGray;border:2px solid #F3F3F5;border-radius:45px;
                            font-size:14pt; font-weight:400;font-family: Roman times;} ''')

        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)  # 隐藏边框

    def showDialog(self):
        fname = QFileDialog.getOpenFileName(self, 'open file', './')
        famepath=fname[0]
        print(fname[-5:])
        print(type(famepath))
        if famepath[-5:] != '.pcap':
            QMessageBox.information(self, "提示", "打开文件失败，可能是文件类型错误")
        else:
            ospath="test/"+famepath.split('/')[-1].split('.')[-2]+"/"
            self.nowpath=ospath
        if os.path.exists(ospath):
            filelist=os.listdir(ospath)                #列出该目录下的所有文件名
            for f in filelist:
                filepath = os.path.join( ospath, f )   #将文件名映射成绝对路劲
                if os.path.isfile(filepath):            #判断该文件是否为文件或者文件夹
                    os.remove(filepath)                 #若为文件，则直接删除
                elif os.path.isdir(filepath):
                    shutil.rmtree(filepath,True)        #若为文件夹，则删除该文件夹及文件夹内所有文件
            shutil.rmtree(ospath,True)                 #最后删除img总文件夹

        os.makedirs(ospath) 
        self.textEdit.setText(famepath)
        shutil.copyfile(famepath,ospath+famepath.split('/')[-1])
        transform_pcap(ospath)

    def beginTest(self):
        return_num = 1      #训练模型返回值，表示是否有木马存在，存在为1，不存在为0
        flag = return_num
        if flag == 1:
            QMessageBox.information(self, "警告", "该文件包含木马！！！")   #virusShow变量为窗体颜色显示，若为1，则changecolor到红色
        elif flag == 0:
            QMessageBox.information(self, "提示", "该文件不包含木马。")   #若为0，则changecolor到绿色

class main_widget(QTabWidget):
    def __init__(self,nowpath):
        super().__init__()
        self.nowpath=nowpath
        self.dosomething()
    def dosomething(self):
        if(len(self.nowpath)<=2):
            return
        self.initUI()
        self.show()
    def initUI(self):

        self.tab1 = QWidget()
        self.addTab(self.tab1, "sheet1")
        self.tab2 = QWidget()
        self.addTab(self.tab2, "sheet2")
        self.tab3 = QWidget()
        self.addTab(self.tab3, "sheet3")
        self.tab4 = QWidget()
        self.addTab(self.tab4, "sheet4")

        self.setGeometry(200, 300, 1000, 600)  # 屏幕上坐标（x, y）， 和 窗口大小(宽，高)
        self.setWindowTitle("木马信息")

        hbox = QHBoxLayout(self.tab1)  # 创建布局，可以让控件随着窗口的改变而改变
        self.tab1.onewidget = QFrame()  # 创建一个QFrame窗口。Qwidget也可以
        self.tab1.tableWidget = QTableWidget(1, 38)  # 创建一个表格tablewidget
        self.tab1.tableWidget.geometry()
        self.tab1.tableWidget.setHorizontalHeaderLabels(
            ['DataSet', 'SrcIP', 'DstIP', 'proto', 'src_port', 'dst_port', 'up_pkts', 'dw_pkts', 'up_pl_pkts',
             'dw_pl_pkts', 'up_pl_bytes', 'dw_pl_bytes', 'duration', 'up_min_ipt', 'dw_min_ipt', 'up_max_ipt',
             'dw_max_ipt', 'up_avg_plsize', 'dw_avg_plsize', 'up_min_plsize', 'dw_min_plsize', 'up_max_plsize',
             'dw_max_plsize', 'up_stdev_plsize', 'dw_stdev_plsize', 'up_avg_ipt', 'dw_avg_ipt', 'up_stdev_ipt',
             'dw_stdev_ipt', 'avg_ttl', 'up_avg_plsize/duration', 'num_dns', '上行流速率大小', '下行流速率大小',
             'TCP握手是否正常(-1-没有握手;0-正常;1-源ipSYN为1；2-目的IPSYN=1、ACK=1；3-目的IP多次回应ACK=1)',
             '0-正常；1-ACK=1、URG、FIN、RST同时=1；2-SYN、FIN同时=1；3-ACK、FIN同时=1', 'up_rst', 'dw_rst'])
        self.tab1.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hbox.addWidget(self.tab1.tableWidget)
        self.tab1.setLayout(hbox)
        readExcel.read_excel(self.tab1.tableWidget, 0,self.nowpath)

        hbox = QHBoxLayout(self.tab2)  # 创建布局，可以让控件随着窗口的改变而改变
        self.tab2.onewidget = QFrame()  # 创建一个QFrame窗口。Qwidget也可以
        self.tab2.tableWidget = QTableWidget(1, 38)  # 创建一个表格tablewidget
        self.tab2.tableWidget.geometry()
        self.tab2.tableWidget.setHorizontalHeaderLabels(
            ['数据集名称', 'IP对', '对应流的个数', '每条流持续时间平均值', '上行载荷总量平均值', '上行载荷总量是否平均', '每条流持续时间是否平均', '上行数据包时间间隔平均值是否很小',
             '下行数据包时间间隔平均值是否很小', '上行数据包时间间隔平均值是否为0', '下行数据包时间间隔平均值是否为0', '上行最大时间间隔是否为0', '下行数据包最大时间间隔是否为0',
             '上行最大时间间隔是否一样', '下行最大时间间隔是否一样', '上行平均时间间隔是否一样', '下行平均时间间隔是否一样'])
        self.tab2.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hbox.addWidget(self.tab2.tableWidget)
        self.tab2.setLayout(hbox)
        readExcel.read_excel(self.tab2.tableWidget, 1,self.nowpath)

        hbox = QHBoxLayout(self.tab3)  # 创建布局，可以让控件随着窗口的改变而改变
        self.tab3.onewidget = QFrame()  # 创建一个QFrame窗口。Qwidget也可以
        self.tab3.tableWidget = QTableWidget(1, 61)  # 创建一个表格tablewidget
        self.tab3.tableWidget.geometry()
        self.tab3.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hbox.addWidget(self.tab3.tableWidget)
        self.tab3.setLayout(hbox)
        readExcel.read_excel(self.tab3.tableWidget, 2,self.nowpath)

        hbox = QHBoxLayout(self.tab4)  # 创建布局，可以让控件随着窗口的改变而改变
        self.tab4.onewidget = QFrame()  # 创建一个QFrame窗口。Qwidget也可以
        self.tab4.tableWidget = QTableWidget(1, 3)  # 创建一个表格tablewidget
        self.tab4.tableWidget.geometry()
        self.tab4.tableWidget.setHorizontalHeaderLabels(
            ['ip', 'success_rate', 'time'])
        self.tab4.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hbox.addWidget(self.tab4.tableWidget)
        self.tab4.setLayout(hbox)
        readExcel.read_excel(self.tab4.tableWidget, 3,self.nowpath)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    parent = Ui_widget()
    parent.show()

    sys.exit(app.exec_())